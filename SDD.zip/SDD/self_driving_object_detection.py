import cv2
import time
import json
from typing import List, Dict, Tuple
from threading import Thread

class CameraStream:
    def __init__(self, src: int = 0):
        self.cap = cv2.VideoCapture(src)
        self.ret, self.frame = self.cap.read()
        self.running = True
        self.thread = Thread(target=self.update, daemon=True)
        self.thread.start()

    def update(self):
        while self.running:
            self.ret, self.frame = self.cap.read()

    def read(self) -> Tuple[bool, any]:
        return self.ret, self.frame

    def release(self):
        self.running = False
        self.cap.release()

class ObjectDetection:
    def __init__(self, model_path: str = "yolov8.pt", conf_threshold: float = 0.5):
        self.model = model_path
        self.conf_threshold = conf_threshold

    def detect(self, frame) -> List[Dict]:
        results = self.model(frame)[0]
        detections = []
        for box in results.boxes:
            if box.conf < self.conf_threshold:
                continue
            cls_id = int(box.cls.item())
            x1, y1, x2, y2 = map(int, box.xyxy[0])
            detections.append({
                "label": self.model.names[cls_id],
                "confidence": round(float(box.conf), 2),
                "bbox": [x1, y1, x2, y2]
            })
        return detections

    def draw_detections(self, frame, detections: List[Dict]) -> any:
        for det in detections:
            x1, y1, x2, y2 = det["bbox"]
            label = f'{det["label"]}: {det["confidence"] * 100:.2f}%'
            cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
            cv2.putText(frame, label, (x1, y1 - 10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1)
        return frame

    def export_to_json(self, detections: List[Dict]) -> str:
        data = {
            "timestamp": int(time.time()),
            "detections": detections
        }
        return json.dumps(data)

def main():
    print("Launching self_driving_object_detection system")
    detector = ObjectDetection(model_path="yolov8.pt")
    conf_threshold = 0.4
    camera = CameraStream(src=0)
    try:
        while True:
            ret, frame = camera.read()
            if not ret or frame is None:
                continue
            detections = detector.detect(frame)
            json_output = detector.export_to_json(detections)
            print(json_output)
            annotated_frame = detector.draw_detections(frame, detections)
            cv2.imshow("Self Driving Object Detection", annotated_frame)
            if cv2.waitKey(1) & 0xFF == 27:
                break
    except KeyboardInterrupt:
        print("Interrupted")
    finally:
        camera.release()
        cv2.destroyAllWindows()
        print("self_driving_object_detection system terminated cleanly")

if __name__ == "__main__":
    main()



#'code by paria rahdari'